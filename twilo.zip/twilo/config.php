<?php
///Edit Thes Config To Your  https://www.twilio.com/ info :>
// thes sender Powred By xlead shop ===>https://xlead.pw
// For More Help contact Telegram Telegram @Oklemalis2:
$twilio_account_sid = "AC00d36de29d696366c203760ff7b280c7";
$twilio_auth_token = "c53ddaf101f3783339a5d5a926024561";
$twilio_phone_number = "+16813956639";
?>