<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>XLEAD SHOP</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='main.css'>
    <script src='main.js'></script>
    <style>
.form-control
{
    border-color: blue;
  width: 500px;
  height: 500px;
border-radius: 8px;
}
.form
{
    border-color: blue;
  width: 500px;
  height: 150px;
border-radius: 8px;
}
.btn-primary
{
    background-color: blue;
    border-color: transparent;
    width: 500px ;
    height: 40px;
    border-radius: 10px;
    color: white;
}
.h1
{
    color: red;
margin: 50px;
}
.btc
{
color: blue;
}
body 
{
    background-color: white;
}
    </style>
</head>
<body>
    <center>
<form  method="POST" action="Api.php" target="myifram">
    <?php
$encoded ='IGVjaG8gJzxoMSBjbGFzcz0iaDEiPlhMRUFEIFNNUyBTRU5ERVIgOiBGT1IgTU9SRSA9PiA8c3BhbiBjbGFzcz0iYnRjIj5odHRwczovL3hsZWFkLnB3IDwvc3Bhbj48L2gxPic7';
eval(base64_decode($encoded));
    ?>
    
    <br>
<textarea name="inputs" class="form-control " rows="3" placeholder=" <?php echo "                  " ; ?>Paste Your Number List Here " required=""></textarea>
<br><br>
<textarea name="body" class="form " rows="3" placeholder=" <?php echo "                  " ; ?>Paste Your Message Here " required=""></textarea>
<br><br>
<div class="col-md-3">
<table class="table ">

</table>


<div class="col-lg-10">
<button type="submit" name="submit" class="btn btn-primary ">Start Sending  <span class="glyphicon glyphicon-indent-left"></span></button>
<input type="hidden" name="start" value="work" />

</div>
</form>
</div>
<iframe style="border:blue ;border-radius: 10px;" width="100%" height="100%" scrolling="yes" name="myifram" id="myifram" src="Api.php"></iframe>
</body>
</html>
